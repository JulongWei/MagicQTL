Fixedcim <-
function(dataframe,gen,map,r,window,lasso){    

##Declare the variable
   d<-dataframe
   y<-as.matrix(d[,1])
   x<-as.matrix(d[,-1])
   n<-nrow(y)
   s<-ncol(x)
   r<-r
##
   gen<-gen
   map<-as.data.frame(map)
   m<-nrow(map)
   ccM<-map$cm
   chr<-map$chr
##   
   offset<-lasso$offset
   gen0<-lasso$gen0
   nm<-nrow(gen0)/r
   index<-matrix(seq(1,nm*r),r,nm)
   covar<-lasso$covar  
#   
if (FALSE){
   locus<-c(209,602,1313,1348,1564,1641,1994)
   for ( ii in locus){
     if (ii %in% covar){
       i0<-which(covar==ii)
       covar<-covar[-i0]
     }else{
       next
     }  
   }
}
   mknum<-lasso$mknum
#   cat("covar:",covar,"\n")
#   cat("mknum:",mknum,"\n")


####loglike function   
   loglike<-function(w,y){
       ns<-ncol(w)
#       nr<-as.numeric(qr(w)$rank)
       ww<-t(w)%*%w
       wy<-t(w)%*%y
       yy<-t(y)%*%y
       wwi<-solve(ww+1e-03*diag(ns),tol=1e-50)
       b<-wwi%*%wy
       log.se2<-log(abs(yy-t(wy)%*%b)/(n))
#       log.ww<-unlist(determinant(ww))[1]
#       cc0<-n-ns
       value<--0.5*n*log.se2
#       value<-abs(yy-t(wy)%*%b)
       return(value)   
   }


######    
   y<-y-mean(y)  
   parr<-numeric()
   blupp<-numeric()
   for(k in 1:m){
       sub<-seq(((k-1)*r+1),((k-1)*r+r)) 
       z<-t(gen[sub,])
              
##co.factor#####################################
#####################################################################              
       c1<-ccM[k]-0.5*window
       c3<-ccM[k]+0.5*window
       k1<-ifelse(c1<min(ccM),1,max(which(ccM<=c1)))
       k3<-ifelse(c3>max(ccM),m,min(which(ccM>=c3)))
       summk<-sum(mknum[1:chr])-mknum[chr]
       co.win<-(k1:k3)+summk
       co.rm<-setdiff(covar,co.win)     
       sub0<-index[,co.rm]
       sub0<-as.numeric(matrix(sub0))
       co.gen<-gen0[sub0,]
       co.z<-t(co.gen)  
#  
       fn0<-loglike(w=co.z,y=y)
#       lm0<-lm(y~0+co.z)
#       fn0<-logLik(lm0)[1]
#       cat("co.rm:",k,length(co.rm),"\n")                     
       z<-cbind(z,co.z) 
#       nr<-as.numeric(qr(z)$rank)
       nr<-0
###lrt  
    
       fn1<-loglike(w=z,y=y)
#       lm1<-lm(y~0+z)
#       fn1<-logLik(lm1)[1]
       lrt<-2*(fn1-fn0)
       lrt.p<-pchisq(lrt,df=r-1,lower.tail=FALSE)
       lrt.logp<--log10(lrt.p)
#
if(FALSE){
#       ns<-ncol(z)
       sub0<-1:r
       b<-lm1[[1]]
       y.res<-lm1[[2]]
       vb<-as.matrix(vcov(lm1))[sub0,sub0]
       g<-b[sub0]
       g<-g-mean(g)

#       wald<-t(g)%*%solve(vb+1e-04*diag(r),tol=1e-50)%*%g
#       wald.p<-pchisq(wald,df=r-1,lower.tail=FALSE)
#       wald.logp<--log10(wald.p)              
       sigma2<-sum(y.res^2)/(n)
       gamma<-g
       stderr<-sqrt(diag(vb))
}       
###wald
#       cat(k,nr,"\n") 
       ns<-ncol(z)
       zy<-t(z)%*%y
       zz<-t(z)%*%z   
       #
       zzi<-solve(zz+1e-03*diag(ns),tol=1e-50)
       b<-zzi%*%zy
       s2<-sum((y-z%*%b)^2)/(n-nr)
       v<-zzi*s2
       g<-b-mean(b)
       sub0<-1:r
       g<-g[sub0]
#       g<-g-mean(g)
       v<-abs(v[sub0,sub0])

#       wald<-sum(g^2/diag(v))
       wald<-t(g)%*%solve(v+1e-04*diag(rep(1,r)),tol=1e-50)%*%g
       wald.p<-pchisq(wald,df=r-1,lower.tail=FALSE)
       wald.logp<--log10(wald.p)
       
       gamma<-g
       stderr<-sqrt(diag(v))
       sigma2<-s2
       par<-data.frame(Num=k,chr=chr[k],ccM=ccM[k],lrt,lrt.p,lrt.logp,wald,wald.p,wald.logp,sigma2)
#       par<-data.frame(Num=k,chr=chr[k],ccM=ccM[[k]],lrt,lrt.p,lrt.logp,sigma2)
       blup<-c(gamma,stderr)
       parr<-rbind(parr,par)
       blupp<-rbind(blupp,blup)
   }
   cat("Data of chr have been completed",0,'\n')
   colnames(blupp)<-c(paste("Gamma.",1:r,sep=""),paste("stderr.",1:r,sep=""))
   result<-list(parr=parr,blupp=blupp)
   return(result)
}
