magicScan <-
function(dataframe,gen,map,kk.eigen,nfounders=8,model="Random-A",index=NULL,window=5,step,bychr=1){
       
  d<-dataframe
  kk<-kk.eigen[[1]]
  qq<-kk.eigen[[2]]
  cc<-kk.eigen[[3]]   
  chrnum<-length(gen)
   
  genold<-gen
  if (!is.null(index)){
    gennew<-list()
    for(i in 1:chrnum){
      gennew[[i]]<-as.matrix(gen[[i]][,index])  
    }
    gen<-gennew
  }       

  RR<-mixedPar(dataframe=d,qq=qq,optim.speed=FALSE)
  cat("lambda:",RR$lambda,"Residual error:",RR$se2,"\n")
  cat("Model:",model,"\n")

###
  if (model=="Random-B"|model=="Fixed-B"){
    if(!is.null(index)){     
      kknew<-kk[index,index]
      qqnew<-eigen(kknew,symmetric=TRUE)
      RRnew<-mixedPar(dataframe=d,qq=qqnew,optim.speed=FALSE)
    }else{
      RRnew<-RR
    }
  }

     
##function-1,Random-A,call Rpoly
  if (model=="Random-A"){
    scans<-list()      
    for ( i in 1:chrnum){
      scans[[i]]<-Rpoly(dataframe=d,gen=gen[[i]],map=map[[i]],qq=qq,r=nfounders,mixed=RR,rmfactor=FALSE)
    }
  }


##function-2,Random-B, call Rpoly
  if (model=="Random-B"){
    scans<-list()   
    for ( i in 1:chrnum){
      scans[[i]]<-Rpoly(dataframe=d,gen=gen[[i]],map=map[[i]],qq=qq,r=nfounders,cc=cc,window=window,mixed=RR,mixednew=RRnew,rmfactor=TRUE)
    }
  }
  
   
##function-3,Fixed-A, call Fpoly
  if (model=="Fixed-A"){
    scans<-list()
    for ( i in 1:chrnum){
      scans[[i]]<-Fpoly(dataframe=d,gen=gen[[i]],map=map[[i]],qq=qq,r=nfounders,mixed=RR,rmfactor=FALSE)
    }
  } 
  
  
##function-4, Fixed-B, call Fpoly
  if (model=="Fixed-B"){
    scans<-list()
    for ( i in 1:chrnum){
      scans[[i]]<-Fpoly(dataframe=d,gen=gen[[i]],map=map[[i]],qq=qq,r=nfounders,cc=cc,window=window,mixed=RR,mixednew=RRnew,rmfactor=TRUE)
    }
  } 

      
##function-5,Interval mapping, call Fixed
  if (model=="IM"){
    scans<-list()
    for ( i in 1:chrnum){
      scans[[i]]<-Fixed(dataframe=d,gen=gen[[i]],map=map[[i]],r=nfounders)
    } 
  }
  
##function-6,composite interval mapping, call Fixedcim
  if (model=="CIM"){ 
   
    map0<-as.data.frame(do.call(rbind,map))
    gen0<-as.matrix(do.call(rbind,gen))
    lasso<-effect.fixed(dataframe=d,gen=gen0,map=map0,r=nfounders,step=step,bychr=bychr)
    cat("The number of cofatcors:",length(lasso$covar),"\n")
    cat("cofactor have been completed:",0,"\n")
       
    scans<-list()
    for ( i in 1:chrnum){
      rr<-Fixedcim(dataframe=d,gen=gen[[i]],map=map[[i]],r=nfounders,window=window,lasso=lasso)
      scans[[i]]<-rr
    }         
  }   
     return(scans)
}
