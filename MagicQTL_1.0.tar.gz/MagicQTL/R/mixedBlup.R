mixedBlup <-
function(dataframe,gen,map,qq,r,cc,mixed){

##declare variable
   d<-dataframe
   y<-as.matrix(d[,1])
   x<-as.matrix(d[,-1])
   n<-nrow(y)
#
   mixed<-mixed
   beta<-mixed$beta
   lambda<-mixed$lambda
#
   qq<-qq
   delta<-qq[[1]]
   uu<-qq[[2]]
#
   yu<-t(uu)%*%y
   xu<-t(uu)%*%x
   zeta<-yu-xu%*%beta
   h<-1/(delta*lambda+1)
#
   gen<-gen
   map<-map
   m<-nrow(map)

##Whether compute the gamma value in the condition of Phenotype
   gamma<-matrix(0,m,r)  
   for ( k in 1:m){
       sub<-seq((k-1)*r+1,k*r)
       zu<-t(uu)%*%t(gen[sub,])
       gamma[k,]<-t(zu)%*%diag(h)%*%zeta*(lambda/cc) 
   }
##
   offset<-matrix(0,n,1)
   for (k in 1:m){
       sub<-seq((k-1)*r+1,k*r)
       z<-t(gen[sub,])
       effect<-z%*%as.matrix(gamma[k,],r,1)
       offset<-offset+effect
   }
   Result<-list(gamma=gamma,offset=offset,mknum=m)
   return(Result)
}
