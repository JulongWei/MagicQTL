Fixed <-
function(dataframe,gen,map,r){

 
##Declare the variable
###
   d<-dataframe
   y<-as.matrix(d[,1])
   x<-as.matrix(d[,-1])
   n<-nrow(y)
   s<-ncol(x)
   r<-r
#
   gen<-gen
   map<-as.data.frame(map)
   m<-nrow(map)
   ccM<-map$cm
   chr<-map$chr
#
   loglike<-function(w,y){
       ns<-ncol(w)
       ww<-t(w)%*%w
       wy<-t(w)%*%y
       yy<-t(y)%*%y
       
       b<-solve(ww,wy)
       log.se2<-log(abs(yy-t(wy)%*%b))
#       log.ww<-unlist(determinant(ww))[1]
#       cc0<-(n-ns)*(1-log(n-ns))
       value<--0.5*n*log.se2
       return(value)   
   }

####
   fn0<-loglike(w=x,y=y)
   y<-y-mean(y) 

##loop by marker
###
   parr<-numeric()
   blupp<-numeric()
   for(k in 1:m) {
   
       sub<-seq(((k-1)*r+1),((k-1)*r+r))
       z<-t(gen[sub,])
       nz<-ncol(z)
###lrt       
       fn1<-loglike(w=z,y=y)
       lrt<-2*(fn1-fn0)
       lrt.p<-pchisq(lrt,df=r-s,lower.tail=FALSE)
       lrt.logp<--log10(lrt.p)

###wald
       zy<-t(z)%*%y
       zz<-t(z)%*%z
##       
       b<-solve(zz,zy)
       g<-b-mean(b)
       s2<-as.numeric(sum((y-z%*%b)^2)/(n-r-1))
       v<-solve(zz)*s2
##
       wald<-t(g)%*%solve(v)%*%g
       #sum(g^2/diag(v))
       wald.p<-pchisq(wald,df=r-1,lower.tail=FALSE,log.p=FALSE)
       wald.logp<--log10(wald.p)
##
       ano<-anova(lm(y~z-1))
       ano.q<-as.numeric(ano[1,4])
       ano.p<-as.numeric(ano[1,5])
       ano.logp<--log10(as.numeric(ano[1,5]))
##
       gamma<-g
       stderr<-sqrt(diag(v))
       sigma2<-s2
   
       par<-data.frame(Num=k,chr=chr[k],ccM=ccM[k],lrt,lrt.p,lrt.logp,wald,wald.p,wald.logp,ano.q,ano.p,ano.logp,sigma2)
       blup<-c(gamma,stderr)
       parr<-rbind(parr,par)
       blupp<-rbind(blupp,blup)
   }
   cat("Data of chr have been completed",0,'\n')
   colnames(blupp)<-c(paste0("Gamma",1:r),paste0("stderr",1:r))
   result<-list(parr=parr,blupp=blupp)
   return(result)
}
