co.factor <-
function(step=5,bychr=1,map=map){

  map<-as.data.frame(map)
  chr<-as.numeric(map$chr)
  ccM<-as.numeric(map$cm)
  pos<-NULL
  covar<-NULL
  chrid<-NULL
  nk<-0
  
  markernum<-numeric()
  for(i in 1:max(chr)){
       
    x<-ccM[which(chr==i)]
    nmk<-length(x)
    markernum<-c(markernum,nmk)
    if (i%%bychr==0){
 
      b<-max(x)       
      npt<-as.integer(b/step)
      tmp3<-numeric(npt)
      for( j in 1:npt){
        tmp1<-abs(x-j*step)
        tmp3[j]<-which.min(tmp1)
      }
      if ( npt==1){
        tmp1<-abs(x-b/2)
        tmp3<-which.min(tmp1)
      }
      
      tmp3<-unique(tmp3)
      pos<-c(pos,x[tmp3])
      covar<-c(covar,nk+tmp3)
      chrid<-c(chrid,rep(i,length(tmp3)))
    }
    nk<-nk+nmk
 }

   cofactor<-list(covar=covar,mknum=markernum)
   return(cofactor)
}
