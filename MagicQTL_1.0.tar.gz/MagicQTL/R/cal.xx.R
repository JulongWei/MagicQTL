cal.xx <-
function(x,y,H=NA){
   x<-as.matrix(x)
   y<-as.matrix(y)
   nr<-ncol(x)
   nc<-ncol(y)
   n0<-nrow(x)
#      xx<-matrix(0,nrow=nr,ncol=nc)
#      for ( i in 1:nr){
#         for (j in 1:nc){
#            xx[i,j]<-x[,i]*H*y[,j]
#         }
#      }
   if (is.na(H)) H<-diag(n0)
   xx<-t(x)%*%H%*%y
   xx<-as.matrix(xx)
   return(xx)
}
