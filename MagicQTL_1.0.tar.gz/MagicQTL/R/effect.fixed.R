effect.fixed <-
function(dataframe,gen,map,r,step=20,bychr=1){
  
  d<-dataframe
  y<-d[,1]
  y<-y-mean(y)
  map<-as.data.frame(map)
  m<-nrow(map)
  n<-ncol(gen)
  cofact<-co.factor(step=step,map=map,bychr=bychr)
    
  indx<-matrix(seq(1,m*r),m,r,byrow=TRUE)
  indx<-indx[cofact$covar,]
  indx<-drop(matrix(indx,nrow(indx)*ncol(indx),1))
  indx<-sort(indx)
  co.gen<-gen[indx,]
  co.m<-nrow(co.gen)/r
  co.x<-t(as.matrix(co.gen))
#
#   co.xx<-t(co.x)%*%co.x
#   co.xxi<-solve(co.xx+(0.05e-02)*diag(co.m*r))  
#   co.b<-co.xxi%*%t(co.x)%*%y
#   theta0<-co.b
#   co.bb<-cbind(cofact$covar,matrix(theta0,co.m,r,byrow=T))
#   offset<-co.x%*%co.b
   
  RR<-list(gen0=gen,covar=cofact$covar,mknum=cofact$mknum)
  return(RR)    
}
